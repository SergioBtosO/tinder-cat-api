const mongoose = require('mongoose')
const Schema = mongoose.Schema

const InterationSchema = new Schema({
  catId: String,
  cats_likes: [String],
  ats_unlikes: [String],
  cats_matches: [String]
})

const Interation = mongoose.model('interations', InterationSchema)

module.exports = Interation
